#!/bin/bash

# Unzip the file
unzip /tmp/webapp.zip -d /tmp

# Navigate to the directory
cd /tmp/webapp

# Install npm packages
npm install

npm update

# Run tests
npm run dev

echo "Script execution completed."